#ifndef PARADISGRAINSURFACESERVER_H_
#define PARADISGRAINSURFACESERVER_H_

#include "ParadisSurface.h"

// class ParadisGrainSurfaceServer : public ParadisSurface
// {
// public:
// 	ParadisGrainSurfaceServer();
// 	ParadisGrainSurfaceServer(const ParadisGrainSurfaceServer& oSurface);
// 	~ParadisGrainSurfaceServer();
// 	ParadisGrainSurfaceServer& operator=(const ParadisGrainSurfaceServer&
// oSurface); 	void Reset(); 	virtual void Set(Home_t* poHome); virtual void
// CheckNodes(Home_t* poHome);
//
// private:
//
// protected:
// 	void Initialize();
// 	bool IsPointInside(const Point& oPoint);
// 	double m_dGrainDiameter;
// 	bool m_bIsHalfGrain;
// };

#endif
