clear
b=.249e-9;
muu=74e+9;
nuu=.301;
R=50*b;
N=30;
N_x=81;
N_y=81;
N_z=41;
theta=linspace(0,2*pi,N+1);
x_d=R*[cos(theta)' sin(theta)' 0*theta'];
plot3(x_d(:,1), x_d(:,2), x_d(:,3))

x0=linspace(-2*R,2*R,N_x);
y0=linspace(-2*R,2*R,N_y);
z0=linspace(-R,R,N_z);
[X,Y,Z]=meshgrid(x0,y0,z0);
for i=1:N_x
    for j=1:N_y
        for k=1:N_z
            x(i+(j-1)*N_x+(k-1)*N_y*N_x,1:3)=[x0(i) y0(j) z0(k)];
        end
    end
end

ss0=FieldPointStress(x,x_d(size(x_d,1),:),x_d(1,:),[b,0,0],b,muu,nuu);
for i=1:size(x_d,1)-1
    ss0=ss0+FieldPointStress(x,x_d(i,:),x_d(i+1,:),[b,0,0],b,muu,nuu);
end
ss=reshape(ss0,[N_x,N_y,N_z,6]);
contourf(X(:,:,21),Y(:,:,21),ss(:,:,21,1)+ss(:,:,21,2)+ss(:,:,21,3))
