    %function []=run_main()

%clear;
%close all;
%clc;
clear
load data_fr
T=300;
kbt=1.381e-23*T;
dv=1.4e-30;
omg=dv/0.13;
cmax=1/omg;
chi0=5e-3;

R0=R/2;
gma = [1 1 1];
gma

%sigma=1/2;

%[rho,phi_exact]= exact_sol_ani(X,Y,Z,sigma,gma,R0);
rho=1/(1+(1-chi0)/chi0*exp(-(ss(:,:,:,1)+ss(:,:,:,2)+ss(:,:,:,3))/3*dv/kbt));

phi = coulomb_3d_anisotropic( rho,gma,R0);

%====  Generation of Fourier transform of Kernel ===== %


%errs = max(max(max(abs(phi_exact-phi))))./max(max(max(abs(phi))));
%disp( ['relative maximum error is ' num2str(errs) ] )


%disp('max val of phi and exact solution' )
%
%[ max(max(max( abs( phi ) ))), max(max(max( abs(phi_exact) ))) ]





