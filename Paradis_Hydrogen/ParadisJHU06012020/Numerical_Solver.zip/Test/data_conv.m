function [rn, links] = data_conv(rn0, links0)
N=max(rn0(:,2))+1;
rn(:,1)=rn0(:,1)*N+rn0(:,2);
rn(:,2:4)=rn0(:,3:5);

links(:,1)=links0(:,1)*N+links0(:,2);
links(:,2)=links0(:,3)*N+links0(:,4);
links(:,3:5)=links0(:,5:7);
end

