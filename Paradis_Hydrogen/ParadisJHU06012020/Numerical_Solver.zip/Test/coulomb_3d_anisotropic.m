% This subroutine compute the 3d Coulomb potential defined as
%
%    \phi=1/(4pi r) \ast rho,
%
%  where
%
%       rho is compactly supported  in anisotropic rectangular (with shifted center at the origin)
%
%       [-gma(1), gma(1)]*L \times [-gma(2), gma(2)]*L \times [-gma(3), gma(3)]*L
%
% Author: Yong ZHANG   Date:  23 Apr,2018 @ Beijing

function phi = coulomb_3d_anisotropic( rho,gma,L)

[nx,ny,nz] = size(rho); % size of discretized density
f1 = zeros(2*nx,2*ny,2*nz); f2 = f1; % declare double-sized array
[n1,n2,n3] = size(f1); n = size(rho);

%
% Gaussian-sum approximation over [delta,2*L*norm(gma)]
% corresponds to exponential-sum over [delta^2, (2*L*norm(gma))^2]
%
eps_rel = 1.e-14;
delta = 1.e-4*min(gma./n)*2/pi;
rmin = delta^2; 
rmax = 12;
%rmax = ( 2.0*L*norm(gma) )^2; % span over original domain

[xs,ws,ns] = SumExpPower(0.5,eps_rel,rmin,rmax);
disp(['number of Gaussians:' num2str(ns)])
%
% precomputation of f1, Fourier transform of the singular Kernel
%
k1= [0:n1/2, -n1/2+1:-1];
k2= [0:n2/2, -n2/2+1:-1];
k3= [0:n3/2, -n3/2+1:-1];

vx =zeros(1,n1); vy =zeros(1,n2); vz =zeros(1,n3);
for kk = 1:ns
    
    alpha = sqrt(xs(kk))*gma(1);%*L;
    beta = k1(1:nx+1);
    vx(1:nx+1) = -sqrt(pi)/alpha*real(exp(-1i*beta*pi)).*real(Faddeeva_w(-beta*pi/4/alpha + 2*1i*alpha) )*exp(-4*alpha^2);
    vx(1:nx+1) = vx(1:nx+1) + sqrt(pi)/alpha*exp(-beta.^2*pi^2/16/alpha^2);
    vx(n1:-1:nx+2) = vx(2:nx);
    vx = vx*gma(1);
    
    alpha = sqrt(xs(kk))*gma(2);%*L;
    beta = k2(1:ny+1);
    vy(1:ny+1) = -sqrt(pi)/alpha*real(exp(-1i*beta*pi)).*real(Faddeeva_w(-beta*pi/4/alpha + 2*1i*alpha) )*exp(-4*alpha^2);
    vy(1:ny+1) = vy(1:ny+1) + sqrt(pi)/alpha*exp(-beta.^2*pi^2/16/alpha^2);
    vy(n2:-1:ny+2) = vy(2:ny);
    vy = vy*gma(2);
    
    alpha = sqrt(xs(kk))*gma(3);%*L;
    beta = k3(1:nz+1);
    vz(1:nz+1) = -sqrt(pi)/alpha*real(exp(-1i*beta*pi)).*real(Faddeeva_w(-beta*pi/4/alpha + 2*1i*alpha) )*exp(-4*alpha^2);
    vz(1:nz+1) = vz(1:nz+1) + sqrt(pi)/alpha*exp(-beta.^2*pi^2/16/alpha^2);
    vz(n3:-1:nz+2) = vz(2:nz);
    vz = vz*gma(3);
    
    T = vx.'*vy;
    for k = 1:n3
	    f1(:,:,k) =  f1(:,:,k) + ws(kk)*T*vz(k); % summing up vx(i)*vy(j)*vz(k) to f1
    end
    
end

I1 = 2*pi*delta^2-sum(ws.*fext1(sqrt(xs),delta));
I2 = pi*delta^4.0-sum(ws.*fext2(sqrt(xs),delta));
vx = k1*pi/2/gma(1); vy = k2*pi/2/gma(2); vz = k3*pi/2/gma(3);
T = ((vx.^2).')*ones(1,n2) + ones(n1,1)*(vy.^2);
for k = 1:n3
f1(:,:,k) =  f1(:,:,k) + I1-I2/6.0*(T+vz(k)^2);
end
 

% Compute the potential
npx = nx/2+1:nx/2*3; npy = ny/2+1:ny/2*3; npz = nz/2+1:nz/2*3;
f2(npx,npy,npz) = rho; % zero-padding
f2 = ifftn(fftn(f2).*f1);  % mulitpilication in Fourier space
phi = real(f2(npx,npy,npz))*L^2/(4*pi); % the final potential

end


function Int0 = fext1(alpha,delta)
%
%  Int0 = (4*pi) int_0^delta exp(-alpha^2 r^2) (r^2dr)
%
% Note that : alpha might be a vector
%
epsCntl = 1e-2; Int0 = zeros(size(alpha));
t =  alpha*delta; t2 = t.*t;

id1 = find(t < epsCntl) ;  id2 = setdiff( 1:length(t), id1);

t4 = t2.^2;t6 = t2.*t4;t8 = t4.*t4;
Int0(id1) = 4.0/3.0-4.0/5.0*t2(id1)+2.0/7.0*t4(id1)-2.0/27.0*t6(id1) + t8(id1)/66.0;
Int0(id1) = Int0(id1)*(pi*delta^3);

Int0(id2) = pi*delta^3.0* (-2*exp(-t2(id2)).*t(id2) + sqrt(pi)*erf(t(id2)))./(t2(id2).*t(id2));

end


function Int2= fext2(alpha,delta)
%
%  Int2 = (4*pi) int_0^delta exp(-alpha^2 r^2) r^2 (r^2dr)
%
epsCntl = 1.d-2; Int2 = zeros(size(alpha));
t = alpha*delta;t2 =t.*t; 
id1 = find(t < epsCntl) ;  id2 = setdiff( 1:length(t), id1);

t4 = t2.*t2; t5 = t.*t4; t6 = t2.*t4;t8 = t4.*t4;

Int2(id1) = 1.6-8.0/7.0*t2(id1) +4.0/9.0*t4(id1) - 4.0/33.0*t6(id1) + t8(id1)/39.0;
Int2(id2) = (-2.0*exp(-t2(id2)).*t(id2).*(3.0+2.0*t2(id2)) + 3.0*sqrt(pi)*erf(t(id2)))./t5(id2);

Int2 = Int2*(pi/2.0*delta^5.0);

end
