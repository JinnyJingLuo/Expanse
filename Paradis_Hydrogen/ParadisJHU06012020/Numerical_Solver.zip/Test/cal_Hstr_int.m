load data_fr
T=300;
kbt=1.381e-23*T;
dv=1.4e-30;
omg=dv/0.13;
cmax=1/omg;
chi0=5e-3;

chi=1/(1+(1-chi0)/chi0*exp(-(ss(:,:,:,1)+ss(:,:,:,2)+ss(:,:,:,3))/3*dv/kbt));
sig_xx_int=zeros(N_x,N_y);
sig_yy_int=zeros(N_x,N_y);
sig_xy_int=zeros(N_x,N_y);
tic
deltav=6^3*R^3/(N_x-1)/(N_y-1)/(N_z-1);
k=31;
for i=1:N_x
    for j=1:N_y
            for ii=1:N_x
                for jj=1:N_y
                    for kk=1:N_z
                        sig_xy_int(i,j)=sig_xy_int(i,j)-(chi(ii,jj,kk)-chi0)*cmax*dv*muu*(1+nuu)/3/pi/(1-nuu)*3/2*(x0(i)-x0(ii))*(y0(j)-y0(jj))/((x0(i)-x0(ii))^2+(y0(j)-y0(jj))^2+(z0(k)-z0(kk))^2)^(2.5)*deltav;
                    end
            end
        end
    end
    display(i/N_x)
end
toc