load links_1
load rn_1
N=15;
b=.249e-9;
muu=72e+9;
nuu=0.305;
[rn,links]=data_conv(rn_1,links_1);

x=linspace(-.5e-6,.5e-6,2*N+1);
y=linspace(-.5e-6,.5e-6,2*N+1);
[X,Y]=meshgrid(x,y);

s_xx=zeros(2*N+1,2*N+1);
s_yy=zeros(2*N+1,2*N+1);
s_zz=zeros(2*N+1,2*N+1);
s_xy=zeros(2*N+1,2*N+1);
s_xz=zeros(2*N+1,2*N+1);
s_yz=zeros(2*N+1,2*N+1);

for i=1:2*N+1
    display(i)
    for j=1:2*N+1
        for k=1:size(links,1)
            ind1=find(rn(:,1)==links(k,1));
            ind2=find(rn(:,1)==links(k,2));
            ss=FieldPointStress([x(i) y(j) 0],rn(ind1,2:4)*b,rn(ind2,2:4)*b,links(k,3:5)*b,b,muu,nuu);
            s_xx(i,j)=s_xx(i,j)+ss(1);
            s_yy(i,j)=s_yy(i,j)+ss(2);
            s_zz(i,j)=s_zz(i,j)+ss(3);
            s_xy(i,j)=s_xy(i,j)+ss(4);
            s_yz(i,j)=s_yz(i,j)+ss(5);
            s_xz(i,j)=s_xz(i,j)+ss(6);
        end
    end
end