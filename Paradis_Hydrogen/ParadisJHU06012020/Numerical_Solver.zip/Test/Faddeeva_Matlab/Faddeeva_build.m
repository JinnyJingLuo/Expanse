mex -output Faddeeva_w -O Faddeeva_w_mex.cc Faddeeva.cc
mex -output Faddeeva_erf -O Faddeeva_erf_mex.cc Faddeeva.cc
mex -output Faddeeva_erfc -O Faddeeva_erfc_mex.cc Faddeeva.cc
mex -output Faddeeva_erfi -O Faddeeva_erfi_mex.cc Faddeeva.cc
mex -output Faddeeva_erfcx -O Faddeeva_erfcx_mex.cc Faddeeva.cc
mex -output Faddeeva_Dawson -O Faddeeva_Dawson_mex.cc Faddeeva.cc
