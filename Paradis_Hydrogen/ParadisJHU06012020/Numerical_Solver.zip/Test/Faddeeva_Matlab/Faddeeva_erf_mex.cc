#define FADDEEVA_FUNC Faddeeva::erf
#define FADDEEVA_REAL 1
#include "Faddeeva_mex.cc"
