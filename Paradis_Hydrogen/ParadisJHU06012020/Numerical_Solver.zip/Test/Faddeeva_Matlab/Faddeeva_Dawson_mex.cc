#define FADDEEVA_FUNC Faddeeva::Dawson
#define FADDEEVA_REAL 1
#include "Faddeeva_mex.cc"
