
function  [rho,phi]=exact_sol_ani(X,Y,Z,sigma,gma,R0)
%  
%  \rho = \Delta \phi, in R^3
% 

Rad=(X.^2/gma(1).^2+Y.^2/gma(2).^2+Z.^2/gma(3).^2)/sigma^2;

xc =  R0*gma*2/3.0; xc(3) = 0.0;

Rad1 =((X-xc(1)).^2/gma(1).^2+(Y-xc(2)).^2/gma(2).^2+(Z-xc(3)).^2/gma(3).^2)/sigma^2;
phi= exp(-Rad ) + exp(-Rad1);



gmt = 1.0./gma/sigma;
T1=4*X.^2*gmt(1).^4-2*gmt(1).^2+4*gmt(2).^4*Y.^2-2*gmt(2)^2;
T1 = T1 + 4*gmt(3).^4*Z.^2-2*gmt(3).^2;
rho = -T1.*exp(-Rad);

T1=4*(X-xc(1)).^2*gmt(1).^4-2*gmt(1).^2+4*gmt(2).^4*(Y-xc(2)).^2-2*gmt(2)^2;
T1 = T1 + 4*gmt(3).^4*(Z-xc(3)).^2-2*gmt(3).^2;
rho = rho  -T1.*exp(-Rad1);


end


















