function [xs,ws,nexp] = SumExpPower(beta,reps,dt,Tfinal )
% return sum-of-exponentials approximation for 1/t^beta for 
% Tfinal>t>delta with relative error bounded by reps

% removed the model reduction step and correct some errors in 
% estimating tupper and tlower.

delta = dt/Tfinal;

h = 2*pi/(log(3)+beta*log(1/cos(1))+log(1/reps));

tlower = 1/beta*log(reps*gamma(1+beta));

if beta>=1 
    tupper = log(1/delta)+log(log(1/reps))+log(beta)+1/2;
else
    tupper = log(1/delta)+log(log(1/reps));
end

M = floor(tlower/h);
N = ceil(tupper/h);

n1 = M:-1;
xs1 = -exp(h*n1);
ws1 = h/gamma(beta)*exp(beta*h*n1);
[ws1new,xs1new] = prony(xs1,ws1);

n2= 0:N;
xs2 = exp(h*n2);
ws2 = h/gamma(beta)*exp(beta*h*n2);


xs =[-real(xs1new); real(xs2.')];
ws = [real(ws1new); real(ws2.')];

xs = xs/Tfinal;
ws = ws/Tfinal^beta;

nexp = length(ws);


% test the accuracy on the interval [dt, Tfinal]
m = 10000;

estart = log10(dt);
eend = log10(Tfinal);
texp = linspace(estart,eend,m);
t = 10.^texp;

ftrue = 1./t.^beta;
fcomp = zeros(size(ftrue));

for i = 1:m
    fcomp(i) = sum(ws.*exp(-t(i)*xs));
end

fcomp = real(fcomp);

norm((ftrue-fcomp)./ftrue,Inf);

end
%
%
%
function [wsnew, xsnew] = prony(xs,ws)
M = length(xs);  h=zeros(2*M,1);

errbnd = 1e-14;

for j=1:2*M
    h(j)=xs.^(j-1)*ws';
end
C=h(1:M);
R=h(M:2*M-1);
H=hankel(C,R);

% To determine the deficient rank of H
U = zeros(M,M); S= U; V = U;
[U,S,V] = svd(H); 
r = sum( abs(diag(S)) > errbnd);  % [length(xs), r]

% Lower rank Approximation, Step 1. find roots  
b = -h(r+1:2*r);
q = H(1:r,1:r)\b; 
Coef = [1; flipud(q)];
xsnew=roots(Coef);

% Lower rank Approximation, Step 2. Compute weights 

% Exact solution 
% A = zeros(r,r);
% for j=1:r
%     A(j,:)= xsnew.^(j-1);
% end
% wsnew = A\h(1:r);

%  L2 approximation %%
A = zeros(2*M,r);
for j=1:size(A,1)
    A(j,:)= xsnew.^(j-1);
end
[U,S,V] = svd(A,0);
s = diag(S); n=length(abs(s)>1e-16);
wsnew = zeros(r,1);
for j =1:n
    wsnew = wsnew+ U(:,j)'*h/s(j)*V(:,j);
end

% disp('relative lsq approximation error =' )
% norm((A*wsnew-h))/norm(h)

ind = find(real(xsnew)<0);
xsnew = xsnew(ind);
wsnew = wsnew(ind);

end
