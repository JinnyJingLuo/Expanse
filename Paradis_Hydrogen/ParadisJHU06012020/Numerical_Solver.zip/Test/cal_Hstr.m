load data_fr.mat
T=300;
kbt=1.381e-23*T;
dv=1.4e-30;
omg=dv/0.13;
cmax=1/omg;
chi0=5e-3;
Hss0=HFieldPointStress(x,x_d(1,:),x_d(2,:),[b,0,0],b,muu,nuu,chi0,cmax,dv,kbt);
Hss=reshape(Hss0,[N_x,N_y,N_z,6]);
