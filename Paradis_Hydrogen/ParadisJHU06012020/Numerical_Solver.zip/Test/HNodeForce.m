function [f3,f4]=HNodeForce(x1,x2,x3,x4,bp,b,a,mu,nu,chi0, cmax, dv, kbt)
% this calculates the forces between dislocation nodes analytically
%inputs: endpoints of dislocation segment starting at x1 ending at x2 with burgers vector bp
%        endpoints of H segment starting at x3 ending at x4 with burgers vector b
%        core paramter a
%        shear modulus mu
%        poisson ration nu
%
%outputs: f3,f4 is the force on nodes located at x3, x4 respectively
                
    f4=[]; 
    f3=[];
    eps=1e-6;
    
    coeff1=mu^2*(1+nu)^2*dv^2/18/pi/(1-nu)^2/kbt*chi0*cmax*(1-chi0); %%coeff1=mu/2/(1-nu)*A1
     
    Diff=x4-x3;
    oneoverL=1./sqrt(sum(Diff.*Diff,2));
    t=Diff.*[oneoverL oneoverL oneoverL];
    Diff=x2-x1;
    oneoverLp=1./sqrt(sum(Diff.*Diff,2));
    tp=Diff.*[oneoverLp oneoverLp oneoverLp];

    c=sum(t.*tp,2);
    c2=c.*c;
    onemc2=1-c2;  
    cL=size(c,1);
    k=1;
    spindex=[];
    for i=1:cL
        index=cL+1-i;
        if onemc2(index)<eps
            spindex(k)=index;
            x1sp(k,:)=x1(index,:);
            x2sp(k,:)=x2(index,:);
            x3sp(k,:)=x3(index,:);
            x4sp(k,:)=x4(index,:);
            bsp(k,:)=b(index,:);
            bpsp(k,:)=bp(index,:);
            x1(index,:)=[];
            x2(index,:)=[];
            x3(index,:)=[];
            x4(index,:)=[];
            bp(index,:)=[];
            b(index,:)=[];
            t(index,:)=[];
            tp(index,:)=[];
            oneoverL(index,:)=[];
            oneoverLp(index,:)=[];
            c(index,:)=[];
            c2(index,:)=[];
            onemc2(index,:)=[];
            k=k+1;
        end
    end
    sL=length(spindex);
    if (cL-sL) > 0
        txtp=[t(:,2).*tp(:,3)-t(:,3).*tp(:,2) , t(:,3).*tp(:,1)-t(:,1).*tp(:,3) , t(:,1).*tp(:,2)-t(:,2).*tp(:,1)];
        onemc2inv=1./onemc2;
        R=[ x3-x1 , x4-x2 ];
        d=sum(R(:,1:3).*txtp,2).*onemc2inv;
        temp1=[sum(R(:,1:3).*t,2) sum(R(:,4:6).*t,2)];
        temp2=[sum(R(:,1:3).*tp,2) sum(R(:,4:6).*tp,2)];
        y=(temp1-[ c c ].*temp2).*[ onemc2inv onemc2inv ];
        z=(temp2-[ c c ].*temp1).*[ onemc2inv onemc2inv ];
        
        yin=[y(:,1) y(:,1) y(:,2) y(:,2)];
        zin=[z(:,1) z(:,2) z(:,1) z(:,2)];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %  this section calculates the formulae from the integral expressions
        a2=a*a;
        a2_d2 = a2+d.*d.*onemc2;
        y2    = yin.*yin;
        z2    = zin.*zin;
        Ra    = sqrt( [a2_d2 a2_d2 a2_d2 a2_d2] + y2 + z2 + 2.*yin.*zin.*[c c c c] );        
        Rainv = 1./Ra;
        
        Ra_Rdot_tp = Ra+zin+yin.*[c c c c];       
        Ra_Rdot_t  = Ra+yin+zin.*[c c c c];       
         
         log_Ra_Rdot_tp =     log(Ra_Rdot_tp);
        ylog_Ra_Rdot_tp = yin.*log_Ra_Rdot_tp;
        
         log_Ra_Rdot_t =     log(Ra_Rdot_t);
        zlog_Ra_Rdot_t = zin.*log_Ra_Rdot_t;
        
          Ra2_R_tpinv = Rainv./Ra_Rdot_tp;
         yRa2_R_tpinv = yin.*  Ra2_R_tpinv;
        y2Ra2_R_tpinv = yin.* yRa2_R_tpinv;
        
          Ra2_R_tinv = Rainv./Ra_Rdot_t;
         zRa2_R_tinv = zin.* Ra2_R_tinv;
        z2Ra2_R_tinv = zin.*zRa2_R_tinv;

        
        denom=1./sqrt(onemc2.*a2_d2);  
        cdenom=(1+c).*denom;
        
        f_003=-2.*[denom denom denom denom].*atan((Ra+yin+zin).*[cdenom cdenom cdenom cdenom]);
        
        adf_003=[a2_d2 a2_d2 a2_d2 a2_d2].*f_003;
        commonf223=( [c c c c].*Ra - adf_003 ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        
        f_103=( [c c c c].*log_Ra_Rdot_t  - log_Ra_Rdot_tp ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_013=( [c c c c].*log_Ra_Rdot_tp - log_Ra_Rdot_t  ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_113=( [c c c c].*adf_003 - Ra ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_203= zlog_Ra_Rdot_t  + commonf223;
        f_023= ylog_Ra_Rdot_tp + commonf223;
        
        commonf225=f_003 - [c c c c].*Rainv;
        commonf025=[c c c c].*yRa2_R_tpinv - Rainv  ;
        ycommonf025=yin.*commonf025;
        commonf205=[c c c c].*zRa2_R_tinv  - Rainv  ;
        zcommonf205=zin.*commonf205;
        commonf305=log_Ra_Rdot_t  -(yin-[c c c c].*zin).*Rainv - [c2 c2 c2 c2].*z2Ra2_R_tinv;
        zcommonf305=zin.*commonf305;
        commonf035=log_Ra_Rdot_tp -(zin-[c c c c].*yin).*Rainv - [c2 c2 c2 c2].*y2Ra2_R_tpinv;
        tf_113=2.*f_113;
        
        f_005=( f_003 - yRa2_R_tpinv - zRa2_R_tinv )./ [a2_d2 a2_d2 a2_d2 a2_d2];
        f_105=( Ra2_R_tpinv - [c c c c].*Ra2_R_tinv  ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_015=( Ra2_R_tinv  - [c c c c].*Ra2_R_tpinv ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_115=( Rainv - [c c c c].*( yRa2_R_tpinv + zRa2_R_tinv + f_003 )).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_205=( yRa2_R_tpinv + [c2 c2 c2 c2].*zRa2_R_tinv  + commonf225 ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_025=( zRa2_R_tinv  + [c2 c2 c2 c2].*yRa2_R_tpinv + commonf225 ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_215=( f_013 - ycommonf025 + [c c c c].*(zcommonf205-f_103) ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_125=( f_103 - zcommonf205 + [c c c c].*(ycommonf025 - f_013) ).*[onemc2inv onemc2inv onemc2inv onemc2inv]; 
        f_225=( f_203 - zcommonf305 + [c c c c].*( y2.*commonf025 - tf_113) ).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_305=(y2Ra2_R_tpinv + [c c c c].*commonf305 + 2.*f_103).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_035=(z2Ra2_R_tinv  + [c c c c].*commonf035 + 2.*f_013).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_315=(tf_113 - y2.*commonf025 + [c c c c].*(zcommonf305 - f_203)).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        f_135=(tf_113 - z2.*commonf205 + [c c c c].*(yin.*commonf035 - f_023)).*[onemc2inv onemc2inv onemc2inv onemc2inv];
        mf=[1 -1 -1 1]';
        Fintegrals=[f_003*mf f_103*mf f_013*mf f_113*mf f_203*mf f_023*mf f_005*mf f_105*mf f_015*mf f_115*mf f_205*mf f_025*mf f_215*mf f_125*mf f_225*mf f_305*mf f_035*mf f_315*mf f_135*mf];
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % this section calculates the dot products and cross prodcucts for the coefficients
        tpxt=-txtp;
        txbp=[t(:,2).*bp(:,3)-t(:,3).*bp(:,2) , t(:,3).*bp(:,1)-t(:,1).*bp(:,3) , t(:,1).*bp(:,2)-t(:,2).*bp(:,1)];
        tpxb=[tp(:,2).*b(:,3)-tp(:,3).*b(:,2) , tp(:,3).*b(:,1)-tp(:,1).*b(:,3) , tp(:,1).*b(:,2)-tp(:,2).*b(:,1)];
        bxt=[b(:,2).*t(:,3)-b(:,3).*t(:,2) , b(:,3).*t(:,1)-b(:,1).*t(:,3) , b(:,1).*t(:,2)-b(:,2).*t(:,1)];
        bpxtp=[bp(:,2).*tp(:,3)-bp(:,3).*tp(:,2) , bp(:,3).*tp(:,1)-bp(:,1).*tp(:,3) , bp(:,1).*tp(:,2)-bp(:,2).*tp(:,1)];
        tdb=sum(t.*b,2);
        tdbp=sum(t.*bp,2);
        tpdb=sum(tp.*b,2);
        tpdbp=sum(tp.*bp,2);
        txtpdb=sum(txtp.*b,2);
        tpxtdbp=sum(tpxt.*bp,2);
        txbpdtp=tpxtdbp;
        tpxbdt=txtpdb;
        
        bpxtpdb=sum(bpxtp.*b,2);
        bxtdbp=sum(bxt.*bp,2);
        txbpdb=bxtdbp;
        tpxbdbp=bpxtpdb;
        txtpxt=tp-[ c c c ].*t;
        tpxtxtp=t-[ c c c ].*tp;
        txtpxbp=[ tdbp tdbp tdbp ].*tp-[tpdbp tpdbp tpdbp ].*t;
        tpxtxb=[tpdb tpdb tpdb].*t-[tdb tdb tdb].*tp;
        txbpxt=bp-[tdbp tdbp tdbp].*t;
        tpxbxtp=b-[tpdb tpdb tpdb].*tp;
        bpxtpxt=[tdbp tdbp tdbp].*tp-[c c c].*bp;
        bxtxtp=[ tpdb tpdb tpdb ].*t-[c c c].*b;
        txtpxbpxt=[tdbp tdbp tdbp].*tpxt;
        tpxtxbxtp=[tpdb tpdb tpdb].*txtp;
        txtpxbpdtp=tdbp-tpdbp.*c;
        tpxtxbdt=tpdb-tdb.*c;
        txtpxbpdb= tdbp.*tpdb-tpdbp.*tdb;
        tpxtxbdbp=txtpxbpdb;   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % this section calculates the coefficients for the second two forces
        I00b= bxt .* [txtpxbpdtp txtpxbpdtp txtpxbpdtp];
        
        temp1=(coeff1*d) .* txtpdb;
        temp2=(coeff1*d) .* bpxtpdb;
        I_003= [coeff1*d coeff1*d coeff1*d].* I00b - [temp1 temp1 temp1].*bpxtpxt - [temp2 temp2 temp2].*txtpxt;
        
        temp1=(coeff1*(d^3)) .*txtpxbpdtp .* txtpdb;
        I_005= [coeff1*d*a^2 coeff1*d*a^2 coeff1*d*a^2].* I00b + [temp1 temp1 temp1].* txtpxt; 
             
        I10b= bxt .*[txbpdtp txbpdtp txbpdtp];
        
        temp1= coeff1 .* tdb;
        I_103= -[temp1 temp1 temp1] .* bpxtpxt + coeff1 .* I10b;
        
        temp1= (coeff1*d^2) .*(txbpdtp.*txtpdb+txtpxbpdtp.*tdb);
        I_105= (coeff1*a^2) .* I10b  +  [temp1 temp1 temp1] .* txtpxt;
                  
        temp1=coeff1 .* tpdb; 
        temp2=coeff1 .* bpxtpdb; 
        I_013= -[temp1 temp1 temp1].*bpxtpxt + [temp2 temp2 temp2] .* txtp;
        
        temp1=(coeff1*(d^2)) .* txtpxbpdtp .* tpdb;
        temp2=(coeff1*(d^2)) .* txtpxbpdtp .* txtpdb;
        I_015= [temp1 temp1 temp1].*txtpxt - [temp2 temp2 temp2] .* txtp;
        
        temp1=((coeff1*d) .* txbpdtp .* tdb);   
        I_205= [temp1 temp1 temp1] .* txtpxt;
        
        temp1=((coeff1*d) .* txtpxbpdtp .* tpdb);
        I_025=-[temp1 temp1 temp1].* txtp;
        
        temp1=(coeff1*d) .*(txtpxbpdtp.*tdb+txbpdtp.*txtpdb);
        temp2=(coeff1*d) .*txbpdtp.*tpdb;
        I_115=-[temp1 temp1 temp1] .*txtp + [temp2 temp2 temp2] .*txtpxt;
        
        temp1=(coeff1 .* txbpdtp .* tdb);
        I_215= -[temp1 temp1 temp1].* txtp;
        
        temp1=(coeff1 .* txbpdtp .* tpdb);
        I_125= -[temp1 temp1 temp1].* txtp;
        
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % this section calculates the second two forces
        Fint_003=Fintegrals(:,2)-y(:,1).*Fintegrals(:,1);
        Fint_103=Fintegrals(:,5)-y(:,1).*Fintegrals(:,2);
        Fint_013=Fintegrals(:,4)-y(:,1).*Fintegrals(:,3);
        Fint_005=Fintegrals(:,8)-y(:,1).*Fintegrals(:,7);
        Fint_105=Fintegrals(:,11)-y(:,1).*Fintegrals(:,8);
        Fint_015=Fintegrals(:,10)-y(:,1).*Fintegrals(:,9);
        Fint_115=Fintegrals(:,13)-y(:,1).*Fintegrals(:,10);
        Fint_205=Fintegrals(:,16)-y(:,1).*Fintegrals(:,11);
        Fint_025=Fintegrals(:,14)-y(:,1).*Fintegrals(:,12);
        Fint_215=Fintegrals(:,18)-y(:,1).*Fintegrals(:,13);
        Fint_125=Fintegrals(:,15)-y(:,1).*Fintegrals(:,14);
        f4=I_003.*[Fint_003 Fint_003 Fint_003] + I_103.*[Fint_103 Fint_103 Fint_103] + I_013.*[Fint_013 Fint_013 Fint_013]; 
        f4=f4 + I_005.*[Fint_005 Fint_005 Fint_005] + I_105.*[Fint_105 Fint_105 Fint_105] + I_015.*[Fint_015 Fint_015 Fint_015];   
        f4=f4 + I_115.*[Fint_115 Fint_115 Fint_115] + I_205.*[Fint_205 Fint_205 Fint_205] + I_025.*[Fint_025 Fint_025 Fint_025]; 
        f4=f4 + I_215.*[Fint_215 Fint_215 Fint_215] + I_125.*[Fint_125 Fint_125 Fint_125];  
        f4=f4.*[oneoverL oneoverL oneoverL] ;
            
        
        Fint_003=y(:,2).*Fintegrals(:,1)-Fintegrals(:,2);
        Fint_103=y(:,2).*Fintegrals(:,2)-Fintegrals(:,5);
        Fint_013=y(:,2).*Fintegrals(:,3)-Fintegrals(:,4);
        Fint_005=y(:,2).*Fintegrals(:,7)-Fintegrals(:,8);
        Fint_105=y(:,2).*Fintegrals(:,8)-Fintegrals(:,11);
        Fint_015=y(:,2).*Fintegrals(:,9)-Fintegrals(:,10);
        Fint_115=y(:,2).*Fintegrals(:,10)-Fintegrals(:,13);
        Fint_205=y(:,2).*Fintegrals(:,11)-Fintegrals(:,16);
        Fint_025=y(:,2).*Fintegrals(:,12)-Fintegrals(:,14);
        Fint_215=y(:,2).*Fintegrals(:,13)-Fintegrals(:,18);
        Fint_125=y(:,2).*Fintegrals(:,14)-Fintegrals(:,15);
        f3=I_003.*[Fint_003 Fint_003 Fint_003] + I_103.*[Fint_103 Fint_103 Fint_103] + I_013.*[Fint_013 Fint_013 Fint_013]; 
        f3=f3 + I_005.*[Fint_005 Fint_005 Fint_005] + I_105.*[Fint_105 Fint_105 Fint_105] + I_015.*[Fint_015 Fint_015 Fint_015];   
        f3=f3 + I_115.*[Fint_115 Fint_115 Fint_115] + I_205.*[Fint_205 Fint_205 Fint_205] + I_025.*[Fint_025 Fint_025 Fint_025]; 
        f3=f3 + I_215.*[Fint_215 Fint_215 Fint_215] + I_125.*[Fint_125 Fint_125 Fint_125];  
        f3=f3.*[oneoverL oneoverL oneoverL] ;
    end
    if sL > 0
        % this is the parallel case the two lines are parallel use a special lower dimensional function
        [f3sp,f4sp]=SpecialHNodeForce(x1sp,x2sp,x3sp,x4sp,bpsp,bsp,a,mu,nu,chi0,cmax,dv,kbt,eps);
        xL=size(x1,1);
        for k=1:sL
            index=sL+1-k;
            pos=spindex(index);
            x1=[x1(1:pos-1,:); x1sp(index,:); x1(pos:xL,:)];
            x2=[x2(1:pos-1,:); x2sp(index,:); x2(pos:xL,:)];
            x3=[x3(1:pos-1,:); x3sp(index,:); x3(pos:xL,:)];
            x4=[x4(1:pos-1,:); x4sp(index,:); x4(pos:xL,:)];
            f3=[f3(1:pos-1,:); f3sp(index,:); f3(pos:xL,:)];
            f4=[f4(1:pos-1,:); f4sp(index,:); f4(pos:xL,:)];
            bp=[bp(1:pos-1,:); bpsp(index,:); bp(pos:xL,:)];
            b=[b(1:pos-1,:); bsp(index,:); b(pos:xL,:)];
            xL=xL+1;
        end
    end

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
function [f3,f4]=SpecialHNodeForce(x1,x2,x3,x4,bp,b,a,mu,nu,chi0,cmax,dv,kbt,ecrit)
% this calculates the forces between dislocation nodes analytically
% this is a special subroutine used for dislocation segments that are too close to parallel to be
% calculated by the regular expression for forces
%inputs: endpoints of first dislocation segment starting at x1 ending at x2 with burgers vector bp
%        endpoints of second dislocation segment starting at x3 ending at x4 with burgers vector b
%        core paramter a
%        shear modulus mu
%        poisson ration nu
%
%outputs: f3,f4 is the force on nodes located at x3, x4 respectively
     cotanthetac=sqrt((1-ecrit*(1.01))/(ecrit*1.01));
     eps=1e-16;
     coeff1=mu^2*(1+nu)^2*dv^2/18/pi/(1-nu)^2/kbt*chi0*cmax*(1-chi0); %%coeff1=mu/2/(1-nu)*A1
     
     Diff=x4-x3;
     oneoverL=1./sqrt(sum(Diff.*Diff,2));
     t=Diff.*[oneoverL oneoverL oneoverL];
     
     Diff=x2-x1;
     oneoverLp=1./sqrt(sum(Diff.*Diff,2));
     tp=Diff.*[oneoverLp oneoverLp oneoverLp];
     
     c=sum(t.*tp,2);
     flipL=0;
     for i=1:size(c,1)
         if c<0
             flipL=flipL+1;
             flip(flipL)=i;
             temp=x2(i,:);
             x2(i,:)=x1(i,:);
             x1(i,:)=temp;
             tp(i,:)=-tp(i,:);
             bp(i,:)=-bp(i,:);
         end
     end
     
     temp=sum((x2-x1).*t,2);
     x2mod=x1+[temp temp temp].*t;
     diff=(x2-x2mod);
     magdiff=sqrt(sum(diff.*diff,2));
     temp=(0.5*cotanthetac).*[magdiff magdiff magdiff].*t;
     x1mod=x1+0.5.*diff+temp;
     x2mod=x2mod+0.5.*diff-temp;
     R=(x3-x1mod);
     Rdt=sum(R.*t,2);
     nd=R-[Rdt Rdt Rdt].*t;
     d2=sum(nd.*nd,2);
     
     r4=sum(x4.*t,2);
     r3=sum(x3.*t,2);
     s2=sum(x2mod.*t,2);
     s1=sum(x1mod.*t,2);
     
     y=[ r3,  r3,  r4,  r4];
     z=[-s1, -s2, -s1, -s2];
     
     a2=a*a;
     a2_d2 = a2+d2;
     temp=1./a2_d2;
     a2d2inv=[temp temp temp temp];
     ypz=y+z;
     ymz=y-z;
     Ra    = sqrt( [a2_d2 a2_d2 a2_d2 a2_d2] + ypz.*ypz);
     Rainv=1./Ra;
     Log_Ra_ypz=log(Ra+ypz);
        
     f_003=Ra.*a2d2inv;
     f_103=-0.5.*(Log_Ra_ypz - ymz.*Ra.*a2d2inv);
     f_013=-0.5.*(Log_Ra_ypz + ymz.*Ra.*a2d2inv);
     f_113=-Log_Ra_ypz;
     f_213=z.*Log_Ra_ypz - Ra;
     f_123=y.*Log_Ra_ypz - Ra;
        
     f_005=a2d2inv.*(2.*a2d2inv.*Ra - Rainv);
     f_105= a2d2inv.*(a2d2inv.*ymz.*Ra - y.*Rainv);
     f_015=-a2d2inv.*(a2d2inv.*ymz.*Ra + z.*Rainv);
     f_115=-a2d2inv.*ypz.*Rainv;
     f_215=  Rainv - z.*f_115;
     f_125=  Rainv - y.*f_115;
     
     mf=[1 -1 -1 1]';
     Fintegrals=[f_003*mf f_103*mf f_013*mf f_113*mf f_213*mf f_123*mf f_005*mf f_105*mf f_015*mf f_115*mf f_215*mf f_125*mf];
     %            1        2        3        4        5        6        7        8        9        10       11       12 
     tdb=sum(t.*b,2);
     tdbv=[tdb tdb tdb];
     tdbp=sum(t.*bp,2);
     tdbpv=[tdbp tdbp tdbp];
     nddb=sum(nd.*b,2);
     nddbv=[nddb nddb nddb];
     bxt=[b(:,2).*t(:,3)-b(:,3).*t(:,2) , b(:,3).*t(:,1)-b(:,1).*t(:,3) , b(:,1).*t(:,2)-b(:,2).*t(:,1)];
     bpxt=[bp(:,2).*t(:,3)-bp(:,3).*t(:,2) , bp(:,3).*t(:,1)-bp(:,1).*t(:,3) , bp(:,1).*t(:,2)-bp(:,2).*t(:,1)];
     ndxt=[nd(:,2).*t(:,3)-nd(:,3).*t(:,2) , nd(:,3).*t(:,1)-nd(:,1).*t(:,3) , nd(:,1).*t(:,2)-nd(:,2).*t(:,1)];
     bpxtdb=sum(bpxt.*b,2);
     bpxtdnd=sum(bpxt.*nd,2);
     bpxtdndv=[bpxtdnd bpxtdnd bpxtdnd];
     bpxtxt=tdbpv.*t - bp;
     
     I_003= -coeff1.*(nddbv.*bpxtxt + [bpxtdb bpxtdb bpxtdb].*ndxt) + coeff1.*(bpxtdndv.*bxt); 
     I_113= -coeff1.*tdbv.*bpxtxt;
     I_005= (coeff1*a^2).*bpxtdndv.*bxt + coeff1.*bpxtdndv.*nddbv.*ndxt;
     I_115= coeff1.*bpxtdndv.*tdbv.*ndxt;
     
     
     Fint_003=Fintegrals(:,2)-y(:,1).*Fintegrals(:,1);
     Fint_113=Fintegrals(:,5)-y(:,1).*Fintegrals(:,4);
     Fint_005=Fintegrals(:,8)-y(:,1).*Fintegrals(:,7);
     Fint_115=Fintegrals(:,11)-y(:,1).*Fintegrals(:,10);
     
     f4=   I_003.*[Fint_003 Fint_003 Fint_003] + I_113.*[Fint_113 Fint_113 Fint_113]; 
     f4=f4+I_005.*[Fint_005 Fint_005 Fint_005] + I_115.*[Fint_115 Fint_115 Fint_115];
     f4=f4.*[oneoverL oneoverL oneoverL];
     
     Fint_003=y(:,3).*Fintegrals(:,1)-Fintegrals(:,2);
     Fint_113=y(:,3).*Fintegrals(:,4)-Fintegrals(:,5);
     Fint_005=y(:,3).*Fintegrals(:,7)-Fintegrals(:,8);
     Fint_115=y(:,3).*Fintegrals(:,10)-Fintegrals(:,11);
     
     f3=   I_003.*[Fint_003 Fint_003 Fint_003] + I_113.*[Fint_113 Fint_113 Fint_113]; 
     f3=f3+I_005.*[Fint_005 Fint_005 Fint_005] + I_115.*[Fint_115 Fint_115 Fint_115];
     f3=f3.*[oneoverL oneoverL oneoverL];
     
     corsize=0;
     for i=1:size(c,1)
         if (diff(i,:)*diff(i,:)')>(eps*(x2mod(i,:)*x2mod(i,:)'+x1mod(i,:)*x1mod(i,:)'))
             corsize=corsize+1;
             corindex(corsize)=i;
             x1mod2(corsize,:)=x1mod(i,:);
             x12(corsize,:)=x1(i,:);
             x2mod2(corsize,:)=x2mod(i,:);
             x22(corsize,:)=x2(i,:);
             x32(corsize,:)=x3(i,:);
             x42(corsize,:)=x4(i,:);
             bp2(corsize,:)=bp(i,:);
             b2(corsize,:)=b(i,:);
         end
     end
     if corsize>0
         [f3cor2,f4cor2]=HNodeForce(x12,x1mod2,x32,x42,bp2,b2,a,mu,nu,chi0,cmax,dv,kbt);
         [f3cor3,f4cor3]=HNodeForce(x2mod2,x22,x32,x42,bp2,b2,a,mu,nu,chi0,cmax,dv,kbt);
         f3cor=zeros(size(c,1),3);
         f4cor=zeros(size(c,1),3);
         for i=1:corsize
             index=corindex(i);
             f3cor(index,:)=f3cor2(i,:)+f3cor3(i,:);
             f4cor(index,:)=f4cor2(i,:)+f4cor3(i,:);
         end
         f3=f3+f3cor;
         f4=f4+f4cor;
     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
     
