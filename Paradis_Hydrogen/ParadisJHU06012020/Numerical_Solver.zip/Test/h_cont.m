clear all

mu=74.73e+09;
nu=0.318;
b=2.49e-10;
core=b;
T=300;
kbt=1.381e-23*T;
dv=1.4e-30;
omg=dv/0.13;
cmax=1/omg;
chi0=5e-3;

t_matrix=[-0.70710678118654746172,0.70710678118654746172,0.0000;0.40824829,0.40824829,-0.81649658;0.57735026918962584208,0.57735026918962584208,0.57735026918962584208];
% x=load('C5H1_rn_200');
% links=load('C5H1_links_200');
x=load('C5H1_rn_50');
links=load('C5H1_links_50');

H=50*b;

node_num=max(x(:,1))+1;
rn=zeros(node_num,3);

for i=1:size(x,1)
    rn(int16(x(i,1))+1,:)=t_matrix*x(i,2:4)';
end

figure
hold on

% for H2
% rn=[-500 500 0;
%     -500 -500  0;
%     -250 500 0;
%     -250 -500  0;
%     0    500 0;
%     0    -500  0;
%     250  500 0;
%     250  -500  0;
%     500  500 0;
%     500  -500  0];
% links=[0 1;
%        2 3;
%        4 5 ;
%        6 7;
%        8 9];

grid_x=(-1500:40:600)*b;
grid_y=(-500:50:500)*b;
grid_z=(-500:50:500)*b;
[MESH_x,MESH_z]=meshgrid(grid_x,grid_z);
c=zeros(size(grid_z,2),size(grid_x,2));
for i=1:size(grid_z,2)
    for j=1:size(grid_x,2)
        stress=[0 0 0 0 0 0];
        for k=1:size(links,1)
            n0=links(k,1)+1;
            n1=links(k,2)+1;
            stress=stress+FieldPointStress([MESH_x(i,j) 0 MESH_z(i,j)],rn(n0,:)*b,rn(n1,:)*b,[b 0 0],core,mu,nu);
        end
        c(i,j)=1/(1+(1-chi0)/chi0*exp(-(stress(1)+stress(2)+stress(3))/3*dv/kbt));
    end
end

 contourf(MESH_x/b,MESH_z/b,c,'LevelStep',1e-5,'LineStyle','none');
 
% t_matrix=[-0.70710678118654746172,0.70710678118654746172,0.0000;0.40824829,0.40824829,-0.81649658;0.57735026918962584208,0.57735026918962584208,0.57735026918962584208];
%  x=load('C5H2_rn_200');
%  links=load('C5H2_links_200');


 node_num=max(x(:,1))+1;
rn=zeros(node_num,3);

for i=1:size(x,1)
    rn(int16(x(i,1))+1,:)=t_matrix*x(i,2:4)';
end

for k=1:size(links,1)
            n0=links(k,1)+1;
            n1=links(k,2)+1;
%            plot3(rn([n0,n1],1),rn([n0,n1],2),[0 0],'g','LineWidth',2);
            if rn(n0,2)*rn(n1,2)<0
             xx=(rn(n0,1)+rn(n1,1))/2;
             zz=(rn(n0,3)+rn(n1,3))/2;
             plot([xx-30 xx+30],[zz zz],'k','LineWidth',2);
             plot([xx xx],[zz zz+20],'k','LineWidth',2);
            end
end
%  
box on
set(0,'defaulttextinterpreter','latex')
xlabel('$x$','FontSize',18);
ylabel('$z$','FontSize',18);
set(gca,'FontSize',12);
xticks([-1500 -1000 -500 0 500 1000]);
xticklabels({'$-1500b$','$-1000b$','$-500b$','$0$','$500b$','$1000b$'});
yticks([-500 0 500]);
yticklabels({'$-500b$','$0$','$500b$'});
set(gca,'TickLabelInterpreter','latex');
set(gca,'TickDir','out');
cb=colorbar('outside');
caxis([4.4e-3 5.6e-3]);
% cb.Label.String='$c$';
% cb.Label.Interpreter='LaTex';
% cb.Label.FontSize=18;
% %cb.AxisLocation='out';
% cb.TickLabelInterpreter ='LaTex';
%cb.Ticks=[0.5 0.99];
%cb.TickLabels={'0.5','1'};
