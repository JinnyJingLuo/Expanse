// EZMath library by Ahmed M. Hussein
// July 2009
// Feel free to use and distribute, but please cite or acknowledge, thanks. 

#include "Patch.h"


namespace GeometrySystem
{
	Patch::~Patch()
	{
		
	}
}


